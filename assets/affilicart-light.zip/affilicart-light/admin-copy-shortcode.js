/**
 * Copy to Clipboard functionality for admin product list
 */
(function() {
    'use strict';
    
    window.copyShortcodeFromElement = function(elementId, buttonElement) {
        const codeElement = document.getElementById(elementId);
        if (!codeElement) {
            console.error('Code element not found:', elementId);
            alert('Error: Could not find shortcode element');
            return false;
        }
        
        const shortcodeText = codeElement.textContent || codeElement.innerText;
        if (!shortcodeText) {
            console.error('No text found in element:', elementId);
            alert('Error: Could not get shortcode text');
            return false;
        }
        
        console.log('Copying text:', shortcodeText);
        
        // Try Clipboard API first
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(shortcodeText).then(function() {
                showCopySuccess(buttonElement);
            }).catch(function(err) {
                console.error('Clipboard API failed:', err);
                fallbackCopy(shortcodeText, buttonElement);
            });
        } else {
            // Use fallback for older browsers
            fallbackCopy(shortcodeText, buttonElement);
        }
        
        return false;
    };
    
    function fallbackCopy(text, buttonElement) {
        console.log('Using fallback copy for:', text);
        
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.top = '0';
        textarea.style.left = '0';
        textarea.style.width = '2em';
        textarea.style.height = '2em';
        textarea.style.padding = '0';
        textarea.style.border = 'none';
        textarea.style.outline = 'none';
        textarea.style.boxShadow = 'none';
        textarea.style.background = 'transparent';
        textarea.style.opacity = '0';
        textarea.style.pointerEvents = 'none';
        
        document.body.appendChild(textarea);
        textarea.focus();
        textarea.select();
        
        try {
            const success = document.execCommand('copy');
            console.log('execCommand copy result:', success);
            if (success) {
                showCopySuccess(buttonElement);
            } else {
                alert('Failed to copy to clipboard');
            }
        } catch (err) {
            console.error('execCommand failed:', err);
            alert('Error copying to clipboard: ' + err.message);
        }
        
        document.body.removeChild(textarea);
    }
    
    function showCopySuccess(buttonElement) {
        if (!buttonElement) return;
        
        console.log('Showing copy success');
        const originalHTML = buttonElement.innerHTML;
        const originalColor = buttonElement.style.color || '#666666';
        
        buttonElement.innerHTML = '<span class="dashicons dashicons-yes"></span>';
        buttonElement.style.color = '#28a745';
        
        setTimeout(function() {
            if (buttonElement && buttonElement.parentNode) {
                buttonElement.innerHTML = originalHTML;
                buttonElement.style.color = originalColor;
            }
        }, 2000);
    }
})();
